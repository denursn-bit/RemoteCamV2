# No custom ProGuard rules for V2.
