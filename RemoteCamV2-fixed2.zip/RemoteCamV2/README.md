# RemoteCam V2

One APK for two Android phones: one can act as **Camera**, the other as **Viewer**. The connection is designed for different networks (Wi-Fi or cellular) using WebRTC/PeerJS signaling.

## Important
- This is a V2 prototype. The project is configured to build in GitHub Actions, but the APK still needs a real-device test after the first build.
- Camera mode is transparent: Android camera permission is required and the system camera indicator can appear. This is not intended for hidden surveillance.
- Keep Camera mode open in the foreground. Android may suspend camera/WebView work when the app is backgrounded or the phone enters aggressive battery saving.
- WebRTC media is protected by the WebRTC transport encryption (DTLS-SRTP). PeerJS is used for signaling/brokering; video is peer-to-peer when the network allows it. Some networks may require TURN for reliable connectivity; this V2 prototype does not include a private TURN server.
- Pairing uses an 8-digit code as the PeerJS ID. Do not share the code publicly.

## GitHub setup
1. Upload the **contents** of this ZIP to the root of the `RemoteCamV2` repository, not the ZIP file itself.
2. Push/commit to `main`.
3. GitHub Actions will build `app-debug.apk` as an artifact.
4. The Pages workflow publishes the web UI used by the APK at `https://denursn-bit.github.io/RemoteCamV2/`.
5. Install the artifact APK on both phones.

## GitHub Pages setting
The included Pages workflow uses GitHub Actions deployment. If Pages is not enabled yet, open repository **Settings → Pages** and select **GitHub Actions** as the source.

## Architecture
- Android wrapper: WebView + runtime camera/microphone permission handling.
- Web UI: PeerJS 1.5.4 + WebRTC.
- Camera: `getUserMedia()` publishes the rear/front camera stream.
- Viewer: creates a silent local audio track (no microphone capture) so PeerJS can originate a media call, then receives the camera video.

## Later V2.x/V3 ideas
- Private signaling server and TURN server.
- Strong pairing using a short-lived QR code plus secret.
- Foreground service/native CameraX/WebRTC for better background reliability.
- Gallery/file transfer with explicit authentication.
